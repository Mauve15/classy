<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Inertia\Inertia;
use App\Models\Jadwal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class JadwalController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        // Ambil jadwal hanya untuk kelas yang sesuai dengan user
        $jadwals = Jadwal::where('kelas_id', $user->kelas_id)
            ->with('kelas')
            ->get()
            ->map(function ($jadwal) {
                return [
                    'id' => $jadwal->id,
                    'nama_matkul' => $jadwal->nama_matkul,
                    'nama_dosen' => $jadwal->nama_dosen,
                    'ruang' => $jadwal->ruang,
                    'hari' => $jadwal->hari,
                    'waktu_mulai' => Carbon::parse($jadwal->waktu_mulai)->format('H:i'),
                    'waktu_selesai' => Carbon::parse($jadwal->waktu_selesai)->format('H:i'),
                    'kelas' => [
                        'id' => $jadwal->kelas->id,
                        'nama_kelas' => $jadwal->kelas->nama_kelas,
                    ],
                ];
            });

        return Inertia::render('jadwal', [
            'jadwals' => $jadwals,
        ]);
    }
}
