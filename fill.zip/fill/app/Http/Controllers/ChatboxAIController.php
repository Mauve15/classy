<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Inertia\Inertia;

class ChatboxAIController extends Controller
{
    public function index()
    {
        return Inertia::render('openai/chatboxai');
    }

    public function chatboxAI(Request $request)
    {
        $messages = $request->input('messages');

        if (!is_array($messages)) {
            return response()->json([
                'reply' => 'Format pesan salah.',
            ], 422);
        }

        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . env('GROQ_API_KEY'),
            ])->post('https://api.groq.com/openai/v1/chat/completions', [
                'model' => 'llama3-70b-8192',
                'messages' => $messages,
            ]);

            $data = $response->json();
            $reply = $data['choices'][0]['message']['content'] ?? 'Maaf, tidak ada balasan.';

            return response()->json([
                'reply' => $reply,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'reply' => 'Terjadi kesalahan: ' . $e->getMessage(),
            ], 500);
        }
    }
}

// namespace App\Http\Controllers;

// use Inertia\Inertia;
// use Illuminate\Http\Request;
// use Illuminate\Support\Facades\Http;

// class ChatboxAIController extends Controller
// {
//     public function index()
//     {
//         return Inertia::render('chatboxai');
//     }
//     public function chatboxAI(Request $request)
//     {
//         $messages = $request->input('messages');

//         if (!is_array($messages)) {
//             return response()->json([
//                 'reply' => 'Format pesan salah.',
//             ], 422);
//         }

//         try {
//             $response = Http::withHeaders([
//                 'Authorization' => 'Bearer ' . env('GROQ_API_KEY'),
//             ])->post('https://api.groq.com/openai/v1/chat/completions', [
//                 'model' => 'llama3-70b-8192',
//                 'messages' => $messages,
//             ]);

//             $data = $response->json();

//             $reply = $data['choices'][0]['message']['content'] ?? 'Maaf, tidak ada balasan.';

//             return response()->json([
//                 'reply' => $reply,
//             ]);
//         } catch (\Exception $e) {
//             return response()->json([
//                 'reply' => 'Terjadi kesalahan: ' . $e->getMessage(),
//             ], 500);
//         }
//     }
// } 