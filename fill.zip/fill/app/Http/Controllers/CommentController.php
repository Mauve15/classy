<?php

namespace App\Http\Controllers;

use App\Models\Forum;
use App\Models\Comment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CommentController extends Controller
{
    public function store(Request $request, $forumId)
    {
        $request->validate([
            'isi' => 'required|string',
        ]);

        $forum = Forum::findOrFail($forumId);

        // Cek apakah user dari kelas yang sama
        if ($forum->kelas_id !== Auth::user()->kelas_id) {
            abort(403, 'Akses ditolak');
        }

        Comment::create([
            'forum_id' => $forum->id,
            'user_id' => Auth::id(),
            'isi' => $request->isi,
        ]);

        return back(); // atau redirect()->route('forum.show', $forumId);
    }

    public function update(Request $request, $id)
    {
        $comment = Comment::findOrFail($id);

        if ($comment->user_id !== Auth::user()->id) {
            abort(403, 'Anda tidak memiliki izin untuk mengedit komentar ini.');
        }

        $request->validate([
            'isi' => 'required|string|max:1000',
        ]);

        $comment->update([
            'isi' => $request->isi,
        ]);

        return back(); // atau response()->json([...]) jika SPA
    }


    public function destroy($id)
    {
        $comment = Comment::findOrFail($id);

        // Hanya user yang membuat komentar yang boleh menghapus
        if ($comment->user_id !== Auth::id()) {
            abort(403, 'Akses ditolak');
        }

        $comment->delete();

        return back();
    }
}
