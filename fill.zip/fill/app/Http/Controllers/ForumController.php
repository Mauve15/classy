<?php

namespace App\Http\Controllers;

use Inertia\Inertia;
use App\Models\Forum;
use App\Models\Discussion;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ForumController extends Controller
{
    public function index()
    {
        $forums = Forum::with('user')
            ->where('kelas_id', Auth::user()->kelas_id)
            ->latest()
            ->get();

        return Inertia::render('forum', [
            'forumList' => $forums,
            'auth' => [
                'user' => Auth::user(),
            ],
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'judul' => 'required|string|max:255',
            'isi' => 'required|string',
        ]);

        Forum::create([
            'user_id' => Auth::id(),
            'kelas_id' => Auth::user()->kelas_id,
            'judul' => $request->judul,
            'isi' => $request->isi,
            'slug' => Str::slug($request->judul),
        ]);

        return redirect()->route('forum.index');
    }
    public function show($slug)
    {
        $forum = Forum::where('slug', $slug)->with(['user', 'comments.user'])->firstOrFail();
        return Inertia::render('show', ['forum' => $forum]);
    }

    public function destroy(Forum $forum)
    {
        if (Auth::user()->id !== $forum->user_id) {
            abort(403, 'Kamu tidak memiliki izin untuk menghapus forum ini.');
        }

        $forum->delete();

        return redirect()->route('forum.index')->with('success', 'Forum berhasil dihapus.');
    }
}
