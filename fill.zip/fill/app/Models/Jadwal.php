<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Jadwal extends Model
{
    use HasFactory;

    protected $table = 'jadwals';
    protected $fillable = ['kelas_id', 'nama_dosen', 'nama_matkul', 'ruang', 'hari', 'waktu_mulai', 'waktu_selesai'];

    public function kelas(): BelongsTo
    {
        return $this->belongsTo(Kelas::class, 'kelas_id');
    }
    public function user()
    {
        return $this->belongsTo(User::class, 'users_id');
    }

    public function tugas()
    {
        return $this->hasMany(Tugas::class, 'jadwals_id');
    }
}
