// import { PlaceholderPattern } from '@/components/ui/placeholder-pattern';
// import AppLayout from '@/layouts/app-layout';
// import { type BreadcrumbItem } from '@/types';
// import { Head, usePage } from '@inertiajs/react';


// const breadcrumbs: BreadcrumbItem[] = [
//     {
//         title: 'Dashboard',
//         href: '/dashboard',
//     },
// ];

// interface Mahasiswa {
//     id: number;
//     name: string;
//     nim: string;
//     kelas_id: number;
//     kelas: {
//         id: number;
//         nama_kelas: string;
//     };
//     is_online: boolean;
// }

// export default function Dashboard() {
//     const props = usePage().props;
    
// console.log("usePage().props:", props); 
// const mahasiswaa = props.mahasiswa as Mahasiswa[] ?? [];
// console.log("Data Mahasiswa:", mahasiswaa);

// const mahasiswa = props.mahasiswa ?? []; 
// console.log("Data Mahasiswa:", mahasiswa);
//     const newLocal = "border-sidebar-border/70 dark:border-sidebar-border relative min-h-[100vh] flex-1 overflow-hidden md:min-h-min";
//     return (
//         <AppLayout breadcrumbs={breadcrumbs}>
//             <Head title="Dashboard" />
//             <div className="flex h-full 20 flex-1 flex-col gap-4 rounded-xl p-4">
            
//                 <h1 className="text-xl font-bold">Mahasiswa : {mahasiswaa.length}</h1>
//                 <div className={newLocal}>
//                     <table className="min-w-full border-collapse border border-gray-300 mt-4">
//                         <thead>
//                             <tr className="bg-gray-300">
//                                 <th className="border border-gray-300 p-2">Nama</th>
//                                 <th className="border border-gray-300 p-2">NIM</th>
//                                 <th className="border border-gray-300 p-2">Status</th>
//                                 {/* <th className="border border-gray-300 p-2">Kelas</th> */}
//                             </tr>
//                         </thead>
//                         <tbody>
 

//                             {Array.isArray(mahasiswa) && mahasiswa.length > 0 ? (
//                                 mahasiswa.map((mhs) => (
//                                 <tr key={mhs.id} className="text-center">
//                                     <td className="border border-gray-300 p-2">{mhs.name}</td>
//                                     <td className="border border-gray-300 p-2">{mhs.nim}</td>
//                                     {/* <td className="border border-gray-300 p-2">{mhs.kelas.nama_kelas}</td> */}
//                                 </tr>
//                             ))
//                             ) : (
//                                 <tr>
//                                     <td colSpan={3} className="text-center p-4">
//                                         Tidak ada data mahasiswa.
//                                     </td>
//                                 </tr>
//                             )}
//                                                    <td className="border border-gray-300 p-2 flex items-center justify-center gap-2">
//     {mhs.is_online ? (
//         <CheckCircle className="text-green-500 w-5 h-5" />
//     ) : (
//         <XCircle className="text-gray-400 w-5 h-5" />
//     )}
//     {mhs.is_online ? "Online" : "Offline"}
// </td>
//                         </tbody>
//                     </table>
//                 </div>
//                 <div className="grid auto-rows-min gap-4 md:grid-cols-3">
//             <div className="border-sidebar-border/70 dark:border-sidebar-border relative aspect-video overflow-hidden rounded-xl flex justify-center items-center">

//                         {/* <PlaceholderPattern className="absolute inset-0 size-full stroke-neutral-900/20 dark:stroke-neutral-100/20" /> */}
//                         <a href="https://my.unpam.ac.id/" className="href flex justify-center items-center">
//                         <img src="img/logounpam.png" alt="Unpam" className="max-w-40 max-h-40 object-contain" /></a>
//                     </div>
//                     <div className="border-sidebar-border/70 dark:border-sidebar-border relative aspect-video overflow-hidden rounded-xl flex justify-center items-center">

//                         {/* <PlaceholderPattern className="absolute inset-0 size-full stroke-neutral-900/20 dark:stroke-neutral-100/20" /> */}
//                         <a href="https://mentari.unpam.ac.id/" className="href flex justify-center items-center">
//                         <img src="img/ems.png" alt="mentari" className="src" />
//                         </a>
//                     </div>
//                     <div className="border-sidebar-border/70 dark:border-sidebar-border relative aspect-video overflow-hidden rounded-xl flex justify-center items-center">
//                         {/* <PlaceholderPattern className="absolute inset-0 size-full stroke-neutral-900/20 dark:stroke-neutral-100/20" /> */}
//                     <a href="https://event.unpam.ac.id/" className="href flex justify-center items-center">
//                     <img src="img/mentari.png" alt="mentari" className="src" />
//                     </a>
//                     </div>
//                 </div>
//             </div>
//         </AppLayout>
//     );
// }
// ==========================================================================================================================
import { CheckCircle, XCircle } from "lucide-react";
import AppLayout from '@/layouts/app-layout';
import { type BreadcrumbItem } from '@/types';
import { Head, usePage } from '@inertiajs/react';
import { Download } from "lucide-react";

const handleDownloadPDF = () => {
    window.open(route('export.pdf'), '_blank');
};
const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Dashboard',
        href: '/dashboard',
    },
];

interface Mahasiswa {
    id: number;
    name: string;
    nim: string;
    kelas_id: number;
    kelas: {
        id: number;
        nama_kelas: string;
    };
    is_online: boolean;
}

export default function Dashboard() {
    const props = usePage().props;
    
    console.log("usePage().props:", props); 
    const mahasiswa = props.mahasiswa as Mahasiswa[] ?? [];

    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="Dashboard" />
          
            <div className="flex h-full flex-1 flex-col gap-4 rounded-xl p-4">
        
                <h1 className="text-xl font-bold">Mahasiswa : {mahasiswa.length}</h1>
                <div className="border-sidebar-border/70 dark:border-sidebar-border relative min-h-[100vh] flex-1 overflow-hidden md:min-h-min">
                    {/* <table className="min-w-full border-collapse border border-gray-300 mt-4">
                        <thead>
                            <tr className="bg-gray-300">
                                <th className="border border-gray-300 p-2">Nama</th>
                                <th className="border border-gray-300 p-2">NIM</th>
                                <th className="border border-gray-300 p-2">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {Array.isArray(mahasiswa) && mahasiswa.length > 0 ? (
                                mahasiswa.map((mhs) => (
                                    <tr key={mhs.id} className="text-center">
                                        <td className="border border-gray-300 p-2">{mhs.name}</td>
                                        <td className="border border-gray-300 p-2">{mhs.nim}</td>
                                        <td className="border border-gray-300 p-2 flex items-center justify-center gap-2">
                                            {mhs.is_online ? (
                                                <CheckCircle className="text-green-500 w-5 h-5" />
                                            ) : (
                                                <XCircle className="text-gray-400 w-5 h-5" />
                                            )}
                                            {mhs.is_online ? "Online" : "Offline"}
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan={3} className="text-center p-4">
                                        Tidak ada data mahasiswa.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table> */}
                    <div className="overflow-x-auto shadow-md rounded-lg mt-6">
    <table className="min-w-full text-sm border border-blue-300 rounded-lg overflow-hidden">
        <thead className="bg-gradient-to-r from-blue-200 to-blue-300 text-gray-700">
            <tr>
                <th className="px-4 py-2 text-left border-b border-blue-300">Nama</th>
                <th className="px-4 py-2 text-left border-b border-blue-300">NIM</th>
                <th className="px-4 py-2 text-left border-b border-blue-300">Status</th>
            </tr>
        </thead>
        <tbody className="text-blue-500">
            {Array.isArray(mahasiswa) && mahasiswa.length > 0 ? (
                mahasiswa.map((mhs) => (
                    <tr
                        key={mhs.id}
                        className="hover:bg-blue-100 even:bg-blue-50 transition duration-200 ease-out-in"
                    >
                        <td className="px-4 py-2 border-b border-blue-200">{mhs.name}</td>
                        <td className="px-4 py-2 border-b border-blue-200">{mhs.nim}</td>
                        <td className="px-4 py-2 border-b border-blue-200">
                            <div className="flex items-center gap-2">
                                {mhs.is_online ? (
                                    <CheckCircle className="text-green-400 w-5 h-5" />
                                ) : (
                                    <XCircle className="text-blue-400 w-5 h-5" />
                                )}
                                <span>{mhs.is_online ? "Online" : "Offline"}</span>
                            </div>
                        </td>
                    </tr>
                ))
            ) : (
                <tr>
                    <td colSpan={3} className="text-center text-gray-500 py-4">
                        Tidak ada data mahasiswa.
                    </td>
                </tr>
            )}
        </tbody>
    </table>
</div>

                </div>
                <div>
        <button 
            onClick={handleDownloadPDF} 
            className="bg-blue-500 text-white px-2 py-2 rounded-md flex items-center gap-1">
            <Download className="w-5 h-5" />
            Export PDF
        </button>

    </div> 
                {/* <div className="grid auto-rows-min gap-1 m-5 md:grid-cols-3">
                    
                    <div className="border-sidebar-border/70 dark:border-sidebar-border relative aspect-video overflow-hidden rounded-xl flex justify-center items-center">
                        <a href="https://event.unpam.ac.id/" className="flex justify-center items-center">
                            <img src="img/ems.png" alt="Mentari" className="object-contain" />
                        </a>
                    </div>
                    <div className="border-sidebar-border/70 dark:border-sidebar-border relative aspect-video overflow-hidden rounded-xl flex justify-center items-center">
                        <a href="https://my.unpam.ac.id/" className="flex justify-center items-center">
                            <img src="img/logounpam.png" alt="Unpam" className="max-w-40 max-h-40 object-contain" />
                        </a>
                    </div>
                    <div className="border-sidebar-border/70 dark:border-sidebar-border relative aspect-video overflow-hidden rounded-xl flex justify-center items-center">
                        <a href="https://mentari.unpam.ac.id/" className="flex justify-center items-center">
                            <img src="img/mentari.png" alt="Mentari" className="object-contain" />
                        </a>
                    </div>
                </div> */}
                <div className="grid auto-rows-min gap-5 m-5 md:grid-cols-3">
  {[
    { href: "https://event.unpam.ac.id/", img: "img/ems.png", alt: "EMS" },
    { href: "https://my.unpam.ac.id/", img: "img/logounpam.png", alt: "Unpam" },
    { href: "https://mentari.unpam.ac.id/", img: "img/mentari.png", alt: "Mentari" },
  ].map(({ href, img, alt }, index) => (
    <div
      key={index}
      className="border border-sidebar-border/70 dark:border-sidebar-border relative aspect-video overflow-hidden rounded-2xl bg-white dark:bg-gray-900 
                 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:ring-2 ring-primary/50 hover:rotate-1"
    >
      <a href={href} className="w-full h-full flex justify-center items-center">
        <img
          src={img}
          alt={alt}
          className={`object-contain grayscale hover:grayscale-0 transition-all duration-300
            ${alt === "EMS" ? "max-h-34 max-w-70" : ""}
            ${alt === "Mentari" ? "max-h-34 max-w-70" : ""}
            ${alt === "Unpam" ? "max-h-40 max-w-40" : ""}
          `}
        />
      </a>
    </div>
  ))}
</div>



            </div>
          
        </AppLayout>
    );
}
// ========================================================================================================================================
// import { CheckCircle, XCircle } from "lucide-react";
// import AppLayout from '@/layouts/app-layout';
// import { type BreadcrumbItem } from '@/types';
// import { Head, usePage, router } from '@inertiajs/react';

// const breadcrumbs: BreadcrumbItem[] = [
//     {
//         title: 'Dashboard',
//         href: '/dashboard',
//     },
// ];

// interface Mahasiswa {
//     id: number;
//     name: string;
//     nim: string;
//     kelas_id: number;
//     kelas: {
//         id: number;
//         nama_kelas: string;
//     };
//     is_online: boolean;
// }

// export default function Dashboard() {
//     const props = usePage().props;
//     console.log("usePage().props:", props);

//     // Pastikan kita mengambil array data dari pagination
//     const mahasiswa = (props.mahasiswa as { data: Mahasiswa[] })?.data ?? [];
//     const links = (props.mahasiswa as { links: any })?.links ?? [];

//     return (
//         <AppLayout breadcrumbs={breadcrumbs}>
//             <Head title="Dashboard" />
//             <div className="flex h-full flex-1 flex-col gap-4 rounded-xl p-4">
//                 <h1 className="text-xl font-bold">Mahasiswa : {mahasiswa.length}</h1>
                
//                 <div className="border-sidebar-border/70 dark:border-sidebar-border relative min-h-[100vh] flex-1 overflow-hidden md:min-h-min">
//                     <table className="min-w-full border-collapse border border-gray-300 mt-4">
//                         <thead>
//                             <tr className="bg-gray-300">
//                                 <th className="border border-gray-300 p-2">Nama</th>
//                                 <th className="border border-gray-300 p-2">NIM</th>
//                                 <th className="border border-gray-300 p-2">Status</th>
//                             </tr>
//                         </thead>
//                         <tbody>
//                             {mahasiswa.length > 0 ? (
//                                 mahasiswa.map((mhs) => (
//                                     <tr key={mhs.id} className="text-center">
//                                         <td className="border border-gray-300 p-2">{mhs.name}</td>
//                                         <td className="border border-gray-300 p-2">{mhs.nim}</td>
//                                         <td className="border border-gray-300 p-2 flex items-center justify-center gap-2">
//                                             {mhs.is_online ? (
//                                                 <CheckCircle className="text-green-500 w-5 h-5" />
//                                             ) : (
//                                                 <XCircle className="text-gray-400 w-5 h-5" />
//                                             )}
//                                             {mhs.is_online ? "Online" : "Offline"}
//                                         </td>
//                                     </tr>
//                                 ))
//                             ) : (
//                                 <tr>
//                                     <td colSpan={3} className="text-center p-4">
//                                         Tidak ada data mahasiswa.
//                                     </td>
//                                 </tr>
//                             )}
//                         </tbody>
//                     </table>
//                 </div>

//                 {/* Pagination Controls */}
//                 <div className="flex justify-center mt-4 gap-2">
//                     {links.map((link: any, index: number) => (
//                         <button
//                             key={index}
//                             onClick={() => link.url && router.get(link.url)}
//                             disabled={!link.url}
//                             className={`px-4 py-2 border rounded-md ${
//                                 link.active ? 'bg-blue-500 text-white' : 'bg-white text-blue-500'
//                             }`}
//                         >
//                             {link.label.replace('&laquo;', '«').replace('&raquo;', '»')}
//                         </button>
//                     ))}
//                 </div>

//                 <div className="grid auto-rows-min gap-4 md:grid-cols-3">
//                     <div className="border-sidebar-border/70 dark:border-sidebar-border relative aspect-video overflow-hidden rounded-xl flex justify-center items-center">
//                         <a href="https://my.unpam.ac.id/" className="flex justify-center items-center">
//                             <img src="img/logounpam.png" alt="Unpam" className="max-w-40 max-h-40 object-contain" />
//                         </a>
//                     </div>
//                     <div className="border-sidebar-border/70 dark:border-sidebar-border relative aspect-video overflow-hidden rounded-xl flex justify-center items-center">
//                         <a href="https://mentari.unpam.ac.id/" className="flex justify-center items-center">
//                             <img src="img/ems.png" alt="Mentari" className="object-contain" />
//                         </a>
//                     </div>
//                     <div className="border-sidebar-border/70 dark:border-sidebar-border relative aspect-video overflow-hidden rounded-xl flex justify-center items-center">
//                         <a href="https://event.unpam.ac.id/" className="flex justify-center items-center">
//                             <img src="img/mentari.png" alt="Mentari" className="object-contain" />
//                         </a>
//                     </div>
//                 </div>
//             </div>
//         </AppLayout>
//     );
// }
