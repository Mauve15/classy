// import React from 'react';
// import { Link, useForm } from '@inertiajs/react';
// import { PageProps } from '@/types';

// interface ForumItem {
//   id: number;
//   judul: string;
//   user: { name: string };
//   created_at: string;
// }

// export default function ForumPage({ forumList }: PageProps<{ forumList: ForumItem[] }>) {
//   const { data, setData, post, processing, reset } = useForm({
//     judul: '',
//     isi: '',
//   });

//   const handleSubmit = (e: React.FormEvent) => {
//     e.preventDefault();
//     post(route('forum.store'), {
//       onSuccess: () => reset(),
//     });
//   };

//   return (
//     <div className="max-w-4xl mx-auto p-4">
//       <h1 className="text-2xl font-bold mb-4">Forum Diskusi</h1>

//       <form onSubmit={handleSubmit} className="space-y-3 mb-6">
//         <input
//           type="text"
//           className="w-full border p-2 rounded"
//           placeholder="Judul forum"
//           value={data.judul}
//           onChange={(e) => setData('judul', e.target.value)}
//           required
//         />
//         <textarea
//           className="w-full border p-2 rounded"
//           placeholder="Isi diskusi..."
//           value={data.isi}
//           onChange={(e) => setData('isi', e.target.value)}
//           required
//         />
//         <button
//           type="submit"
//           disabled={processing}
//           className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
//         >
//           Buat Forum
//         </button>
//       </form>

//       <div className="space-y-4">
//         {forumList.map((forum) => (
//           <div key={forum.id} className="bg-white shadow p-4 rounded">
//             <Link href={route('forum.show', forum.id)} className="text-xl font-semibold text-blue-600 hover:underline">
//               {forum.judul}
//             </Link>
//             <p className="text-sm text-gray-500">
//               oleh {forum.user.name} - {new Date(forum.created_at).toLocaleString()}
//             </p>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// }
import React from 'react';
import AppLayout from '@/layouts/app-layout'; // Sesuaikan dengan path jika perlu
import { Head, Link, useForm } from '@inertiajs/react';
import { PageProps } from '@/types';
import { router } from '@inertiajs/react';

interface ForumItem {
  id: number;
  slug: string;
  judul: string;
  user: { name: string };
  created_at: string;
}

export default function ForumPage({ auth, forumList }: PageProps<{ forumList: ForumItem[] }>) {
  const { data, setData, post, processing, reset } = useForm({
    judul: '',
    isi: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    post(route('forum.store'), {
      onSuccess: () => reset(),
    });
  };

  const handleDelete = (id: number) => {
    if (confirm('Yakin ingin menghapus forum ini?')) {
      router.delete(route('forum.destroy', id));
    }
  };

  return (
    <AppLayout>
      <Head title="Forum Diskusi" />

      <div className="py-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold mb-6 text-gray-800 dark:text-gray-100">Forum Diskusi</h1>

          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 space-y-6">
            {/* Form Buat Forum */}
            <form onSubmit={handleSubmit} className="space-y-4 mb-8">
              <input
                type="text"
                className="w-full border border-gray-300 dark:border-gray-700 dark:bg-gray-900 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm transition-all"
                placeholder="Judul forum"
                value={data.judul}
                onChange={(e) => setData('judul', e.target.value)}
                required
              />
              <textarea
                className="w-full border border-gray-300 dark:border-gray-700 dark:bg-gray-900 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm transition-all"
                placeholder="Isi diskusi..."
                value={data.isi}
                onChange={(e) => setData('isi', e.target.value)}
                rows={4}
                required
              />
              <button
                type="submit"
                disabled={processing}
                className="bg-blue-600 text-white px-6 py-2 rounded-lg text-sm hover:bg-blue-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Buat Forum
              </button>
            </form>

            {/* List Forum */}
            <div className="space-y-5">
              {forumList.map((forum) => (
                <div
                  key={forum.id}
                  className="bg-gray-100 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl p-5 shadow-md hover:shadow-xl transition-all"
                >
                  <Link
                    href={route('forum.show', forum.slug)}
                    className="text-xl font-semibold text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-600 transition-all"
                  >
                    {forum.judul}
                  </Link>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    oleh <span className="font-medium">{forum.user.name}</span> -{" "}
                    {new Date(forum.created_at).toLocaleString()}
                  </p>

                  {auth.user.name === forum.user.name && (
                    <button
                      onClick={() => handleDelete(forum.id)}
                      className="mt-2 text-sm text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-600 transition-all"
                    >
                      Hapus
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
