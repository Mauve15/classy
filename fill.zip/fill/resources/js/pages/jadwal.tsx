// import { PlaceholderPattern } from '@/components/ui/placeholder-pattern';
// import AppLayout from '@/layouts/app-layout';
// import { type BreadcrumbItem } from '@/types';
// import { Head, usePage } from '@inertiajs/react';

// const breadcrumbs: BreadcrumbItem[] = [
//     {
//         title: 'Jadwal',
//         href: '/jadwal',
//     },
// ];

// interface Jadwal {
//     id: number;
//     nama_matkul: string;
//     nama_dosen: string;
//     ruang: string;
//     waktu_mulai: string;
//     waktu_selesai: string;
//     kelas: {
//         id: number;
//         nama_kelas: string;
//     };
// }

// // Pastikan PageProps didefinisikan dengan extends InertiaPageProps
// interface PageProps extends Record<string, unknown> {
//     jadwals: Jadwal[];
// }

// export default function Jadwal() {
    
    // const { jadwals } = usePage<PageProps>().props;
    // console.log('Data Jadwal:', jadwals); // Debugging data dari backend

    // return (
    //     <AppLayout breadcrumbs={breadcrumbs}>
    //         <Head title="Jadwal" />
    //         <div className="flex h-full flex-1 flex-col gap-4 rounded-xl p-4 text-blue-950 text-sm">
{/* ============= */}
                {/* <div className="grid auto-rows-min gap-4 md:grid-cols-2">
                    <div className="border-sidebar-border/70 dark:border-sidebar-border relative aspect-video overflow-hidden rounded-xl border">
                        <PlaceholderPattern className="absolute inset-0 size-full stroke-neutral-900/20 dark:stroke-neutral-100/20" />
                    </div>

                    <div className="border-sidebar-border/70 dark:border-sidebar-border relative aspect-video overflow-hidden rounded-xl border">
                        <PlaceholderPattern className="absolute inset-0 size-full stroke-neutral-900/20 dark:stroke-neutral-100/20" />
                    </div>
                </div> */}
{/* ======================================= */}
                {/* <div className="border-sidebar-border/70 dark:border-sidebar-border relative min-h-[100vh] flex-1 overflow-hidden rounded-xl border md:min-h-min p-4">
                    <h1 className="text-xl font-bold mb-4">Jadwal Perkuliahan</h1>
                    <div className="overflow-x-auto mt-6 shadow-md rounded-lg">
    <table className="min-w-full text-sm border border-gray-300 rounded-lg overflow-hidden">
        <thead className="bg-gradient-to-r from-gray-200 to-gray-300 text-gray-700">
            <tr>
                <th className="px-4 py-2 text-left border-b border-gray-300">Mata Kuliah</th>
                <th className="px-4 py-2 text-left border-b border-gray-300">Dosen</th>
                <th className="px-4 py-2 text-left border-b border-gray-300">Ruang</th>
                <th className="px-4 py-2 text-left border-b border-gray-300">Waktu Mulai</th>
                <th className="px-4 py-2 text-left border-b border-gray-300">Waktu Selesai</th>
            </tr>
        </thead>
        <tbody className="text-gray-700">
            {jadwals && jadwals.length > 0 ? (
                jadwals.map((jadwal) => (
                    <tr
                        key={jadwal.id}
                        className="hover:bg-gray-100 even:bg-gray-50 transition duration-200 ease-in-out"
                    >
                        <td className="px-4 py-2 border-b border-gray-200">{jadwal.nama_matkul}</td>
                        <td className="px-4 py-2 border-b border-gray-200">{jadwal.nama_dosen}</td>
                        <td className="px-4 py-2 border-b border-gray-200">{jadwal.ruang}</td>
                        <td className="px-4 py-2 border-b border-gray-200">
                            {new Date(jadwal.waktu_mulai).toLocaleString('id-ID', {
                                dateStyle: 'medium',
                                timeStyle: 'short',
                            })}
                        </td>
                        <td className="px-4 py-2 border-b border-gray-200">
                            {new Date(jadwal.waktu_selesai).toLocaleString('id-ID', {
                                dateStyle: 'medium',
                                timeStyle: 'short',
                            })}
                        </td>
                    </tr>
                ))
            ) : (
                <tr>
                    <td
                        colSpan={5}
                        className="text-center text-gray-500 py-4 border-b border-gray-200"
                    >
                        Tidak ada jadwal tersedia.
                    </td>
                </tr>
            )}
        </tbody>
    </table>
</div>

                </div>
            </div>
        </AppLayout>
    );
} */}

import { PlaceholderPattern } from '@/components/ui/placeholder-pattern';
import AppLayout from '@/layouts/app-layout';
import { type BreadcrumbItem } from '@/types';
import { Head, usePage } from '@inertiajs/react';
import { useEffect } from 'react';

const breadcrumbs: BreadcrumbItem[] = [
  {
    title: 'Jadwal',
    href: '/jadwal',
  },
];

interface Jadwal {
  id: number;
  nama_matkul: string;
  nama_dosen: string;
  ruang: string;
  hari: string;
  waktu_mulai: string; // format: "08:30" atau "08:30:00"
  waktu_selesai: string;
  kelas: {
    id: number;
    nama_kelas: string;
  };
}

interface PageProps extends Record<string, unknown> {
  jadwals: Jadwal[];
}

export default function Jadwal() {
  const { jadwals } = usePage<PageProps>().props;

  useEffect(() => {
    if ('Notification' in window) {
      if (Notification.permission !== 'granted') {
        Notification.requestPermission();
      }

      const interval = setInterval(() => {
        const now = new Date();
        const hariIni = now.toLocaleDateString('id-ID', { weekday: 'long' }).toLowerCase();
        const waktuSekarang = now.getHours() * 60 + now.getMinutes();

        jadwals.forEach((jadwal) => {
          const jadwalHari = jadwal.hari.toLowerCase();
          if (hariIni !== jadwalHari) return;

          const [jamMulai, menitMulai] = jadwal.waktu_mulai.split(':').map(Number);
          const waktuJadwal = jamMulai * 60 + menitMulai;
          const selisihMenit = waktuJadwal - waktuSekarang;

          const key = `notified-${jadwal.id}-${hariIni}`;

          if (selisihMenit === 30 && !localStorage.getItem(key)) {
            new Notification(`🕒 30 Menit Lagi: ${jadwal.nama_matkul}`, {
              body: `Kelas bersama ${jadwal.nama_dosen} dimulai pukul ${jadwal.waktu_mulai.slice(0, 5)}.`,
              icon: '/icon.png',
            });
            localStorage.setItem(key, 'true');
          }

          if (selisihMenit < -1) {
            localStorage.removeItem(key);
          }
        });
      }, 60000);

      return () => clearInterval(interval);
    }
  }, [jadwals]);

  return (
    <AppLayout breadcrumbs={breadcrumbs}>
      <Head title="Jadwal" />
      <div className="flex h-full flex-1 flex-col gap-4 rounded-xl p-4 text-blue-950 text-sm">
        <div className="border-sidebar-border/70 dark:border-sidebar-border relative min-h-[100vh] flex-1 overflow-hidden rounded-xl border md:min-h-min p-4">
          <h1 className="text-xl font-bold mb-4">Jadwal Perkuliahan</h1>
          <div className="overflow-x-auto mt-6 shadow-md rounded-lg">
            <table className="min-w-full text-sm border border-gray-300 rounded-lg overflow-hidden">
              <thead className="bg-gradient-to-r from-gray-200 to-gray-300 text-gray-700">
                <tr>
                  <th className="px-4 py-2 text-left border-b border-gray-300">Mata Kuliah</th>
                  <th className="px-4 py-2 text-left border-b border-gray-300">Dosen</th>
                  <th className="px-4 py-2 text-left border-b border-gray-300">Ruang</th>
                  <th className="px-4 py-2 text-left border-b border-gray-300">Hari</th>
                  <th className="px-4 py-2 text-left border-b border-gray-300">Waktu Mulai</th>
                  <th className="px-4 py-2 text-left border-b border-gray-300">Waktu Selesai</th>
                </tr>
              </thead>
              <tbody className="text-gray-700">
                {jadwals && jadwals.length > 0 ? (
                  jadwals.map((jadwal) => (
                    <tr
                      key={jadwal.id}
                      className="hover:bg-gray-100 even:bg-gray-50 transition duration-200 ease-in-out"
                    >
                      <td className="px-4 py-2 border-b border-gray-200">{jadwal.nama_matkul}</td>
                      <td className="px-4 py-2 border-b border-gray-200">{jadwal.nama_dosen}</td>
                      <td className="px-4 py-2 border-b border-gray-200">{jadwal.ruang}</td>
                      <td className="px-4 py-2 border-b border-gray-200">{jadwal.hari}</td>
                      <td>{jadwal.waktu_mulai}</td>
<td>{jadwal.waktu_selesai}</td>

                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="text-center text-gray-500 py-4 border-b border-gray-200">
                      Tidak ada jadwal tersedia.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
