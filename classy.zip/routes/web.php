<?php

use Carbon\Carbon;
use App\Models\User;
use Inertia\Inertia;
use App\Models\Forum;
use App\Models\Tugas;
use Spatie\Sitemap\Sitemap;
use Illuminate\Http\Request;
use Spatie\Sitemap\Tags\Url;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PDFController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ForumController;
use App\Http\Controllers\GenAIController;
use App\Http\Controllers\KelasController;
use App\Http\Controllers\TugasController;
use App\Http\Controllers\ExportController;
use App\Http\Controllers\JadwalController;
use App\Http\Controllers\CommentController;
use App\Http\Controllers\ChatboxAIController;
use App\Http\Controllers\DiscussionController;
use App\Http\Controllers\Auth\RegisteredUserController;

Route::get('/', function () {
    return Inertia::render('welcome');
})->name('home');

Route::get('/acak', [UserController::class, 'acak'])->name('acak');


// Route::get('/forums', function () {
//     return Inertia::render('forum');
// });

Route::get('/register', [RegisteredUserController::class, 'create'])->name('register');

Route::middleware(['auth'])->get('/kelas', [KelasController::class, 'index']);
Route::middleware('auth')->get('/kelas/{kelas_id}', [KelasController::class, 'show']);

Route::get('/jadwal', [JadwalController::class, 'index'])->name('jadwals.index');


// Route::get('/user/{id}/online', [UserController::class, 'isUserOnline']);
Route::get('/user/{id}/online', function ($id) {
    $user = User::find($id);

    if (!$user) {
        return response()->json(['message' => 'User not found'], 404);
    }

    return response()->json(['online' => $user->is_online]);
});

Route::get('/tugas', [TugasController::class, 'index'])->name('tugas.index');


// Route::middleware(['auth', 'verified'])->group(function () {
//     Route::get('/dashboard', function () {
//         $user = Auth::user();
//         $mahasiswa = User::where('kelas_id', $user->kelas_id)->with('kelas')->get();

//         return Inertia::render('dashboard', [
//             'mahasiswa' => $mahasiswa,
//             'tugas' => $tugas,
//         ]);
//     })->name('dashboard');
// });

Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/dashboard', function () {
        $user = Auth::user();

        $mahasiswa = User::where('kelas_id', $user->kelas_id)->with('kelas')->get();

        // Ambil semua tugas untuk kelas user
        $tugas = Tugas::where('kelas_id', $user->kelas_id)->get();

        return Inertia::render('dashboard', [
            'mahasiswa' => $mahasiswa,
            'tugas' => $tugas, // ← Tambahkan ini
        ]);
    })->name('dashboard');
});
// ===========================================
Route::middleware(['auth'])->group(function () {
    Route::get('/forum', [ForumController::class, 'index'])->name('forum.index');
    Route::post('/forum', [ForumController::class, 'store'])->name('forum.store');
    Route::get('/forum/{slug}', [ForumController::class, 'show'])->name('forum.show');
    Route::delete('/forum/{forum}', [ForumController::class, 'destroy'])->name('forum.destroy');
});

Route::post('/forum/{forum}/comments', [DiscussionController::class, 'store'])->name('comments.store');

Route::middleware(['auth'])->group(function () {
    Route::post('/forum/{forum}/comments', [CommentController::class, 'store'])->name('comments.store');
    Route::put('/comments/{comment}', [CommentController::class, 'update'])->name('comments.update');
    Route::delete('/comments/{comment}', [CommentController::class, 'destroy'])->name('comments.destroy');
});

Route::get('/admin/tugas/{id}', [TugasController::class, 'show']);


// Route::get('/chatboxai', function () {
//     return Inertia::render('openai/chatboxai');
// });
// Route untuk halaman utama chatbox AI (Frontend React)
// Route::post('/openai/chatboxai', function (Request $request) {
//     // validasi simple
//     $messages = $request->input('messages');
//     return response()boax->json([
//         'reply' => 'Pesan diterima: ' . json_encode($messages),
//     ]);
// });
// Route::post('/openai/chatboxai', [ChatboxAIController::class, 'chatboxAI']);
// Route::post('/openai/chatboxai', [ChatboxAIController::class, 'chatboxAI']);
// Route::get('/openai/chatboxai', function () {
//     return Inertia::render('openai/chatboxai'); // Pastikan nama file React kamu sesuai
// })->name('chatboxai');

Route::get('/chatboxai', [ChatboxAIController::class, 'index']);
Route::post('/chatboxai', [ChatboxAIController::class, 'chatboxAI']);

Route::get('/test', function () {
    return Inertia::render('test');
});
// Route::get('/tugas/{id}', [TugasController::class, 'show'])->name('tugas.show');
// Route::post('/forum/{forum}/comments', [DiscussionController::class, 'store'])->name('comments.store');


// =================================================
// Route::middleware('auth:sanctum')->group(function () {
//     // Route untuk diskusi
//     Route::get('/discussions/{kelasId}', [DiscussionController::class, 'index']);
//     Route::post('/discussions', [DiscussionController::class, 'store']);
//     Route::delete('/discussions/{id}', [DiscussionController::class, 'destroy']);

//     // Route untuk komentar
//     Route::post('/comments/{discussionId}', [CommentController::class, 'store']);
//     Route::delete('/comments/{id}', [CommentController::class, 'destroy']);
// });

// Route::middleware(['auth'])->group(function () {
//     Route::get('/forum/{kelas}', [DiscussionController::class, 'index'])->name('forum.kelas');
//     Route::post('/forum/{kelas}', [DiscussionController::class, 'store'])->name('forum.store');
// });

// Route::post('/forum/{id}/comment', [CommentController::class, 'store'])->name('comment.store');

// Route::get('/forum/{kelas_id}', [DiscussionController::class, 'index'])->name('forum.kelas');

// Route::post('/forum/comment/{discussion}', [CommentController::class, 'store'])->name('comment.store');

// Route::get('/forum', [DiscussionController::class, 'index'])->name('forum.index');

Route::get('/sitemap.xml', function () {
    $sitemap = Cache::remember('sitemap', 60, function () {
        $sitemap = Sitemap::create()
            ->add(Url::create('/')->setPriority(1.0))
            ->add(Url::create('/register'))
            ->add(Url::create('/jadwal'))
            ->add(Url::create('/tugas'))
            ->add(Url::create('/forum'))
            ->add(Url::create('/chatboxai'));

        // Ambil semua forum dinamis
        $forums = Forum::all();
        foreach ($forums as $forum) {
            $sitemap->add(
                Url::create("/forum/{$forum->slug}")
                    ->setLastModificationDate(Carbon::parse($forum->updated_at))
                    ->setChangeFrequency(Url::CHANGE_FREQUENCY_WEEKLY)
                    ->setPriority(0.8)
            );
        }

        return $sitemap;
    });

    return $sitemap->toResponse(request());
});
Route::get('/export-mahasiswa', [ExportController::class, 'exportExcel'])
    ->middleware('auth')
    ->name('export.mahasiswa');
Route::get('/export/pdf', [PDFController::class, 'exportPDF'])->name('export.pdf');
// Route::middleware(['auth', 'verified'])->group(function () {
//     Route::get('/dashboard', function () {
//         $user = Auth::user();
//         $mahasiswa = User::where('kelas_id', $user->kelas_id)
//             ->with('kelas')
//             ->paginate(10); // Gunakan paginate untuk pagination

//         return Inertia::render('dashboard', [
//             'mahasiswa' => $mahasiswa
//         ]);
//     })->name('dashboard');
// });


require __DIR__ . '/settings.php';
require __DIR__ . '/auth.php';


//WOZBERR