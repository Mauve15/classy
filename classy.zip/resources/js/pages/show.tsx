// import React from 'react';
// import { useForm } from '@inertiajs/react';
// import { PageProps } from '@/types';

// interface Comment {
//   id: number;
//   isi: string;
//   created_at: string;
//   user: {
//     name: string;
//   };
// }

// interface ForumData {
//   id: number;
//   judul: string;
//   isi: string;
//   created_at: string;
//   user: {
//     name: string;
//   };
//   comments: Comment[];
// }

// export default function Show({ forum }: PageProps<{ forum: ForumData }>) {
//   const { data, setData, post, processing, reset } = useForm({
//     isi: '',
//   });

//   const handleSubmit = (e: React.FormEvent) => {
//     e.preventDefault();
//     post(route('comments.store', forum.id), {
//       onSuccess: () => reset(),
//     });
//   };

//   return (
//     <div className="max-w-3xl mx-auto p-4 space-y-6">
//       <div className="bg-white shadow p-4 rounded">
//         <h2 className="text-2xl font-bold">{forum.judul}</h2>
//         <p className="text-gray-600 mb-2">oleh {forum.user.name} - {new Date(forum.created_at).toLocaleString()}</p>
//         <p>{forum.isi}</p>
//       </div>

//       <form onSubmit={handleSubmit} className="bg-gray-50 p-4 rounded shadow space-y-3">
//         <textarea
//           className="w-full border rounded p-2"
//           placeholder="Tulis komentar..."
//           value={data.isi}
//           onChange={(e) => setData('isi', e.target.value)}
//           required
//         />
//         <button
//           type="submit"
//           disabled={processing}
//           className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
//         >
//           Kirim Komentar
//         </button>
//       </form>

//       <div className="space-y-3">
//         <h3 className="text-lg font-semibold">Komentar:</h3>
//         {forum.comments.length === 0 ? (
//           <p className="text-gray-500">Belum ada komentar.</p>
//         ) : (
//           forum.comments.map((comment) => (
//             <div key={comment.id} className="border border-gray-200 p-3 rounded">
//               <p className="text-sm text-gray-700 mb-1">{comment.user.name} - {new Date(comment.created_at).toLocaleString()}</p>
//               <p>{comment.isi}</p>
//             </div>
//           ))
//         )}
//       </div>
//     </div>
//   );
// }
// =================================================================================================
// import React from 'react';
// import { Head, useForm } from '@inertiajs/react';
// import AppLayout from '@/layouts/app-layout';
// import { PageProps } from '@/types';

// interface Comment {
//   id: number;
//   isi: string;
//   created_at: string;
//   user: {
//     name: string;
//   };
// }

// interface ForumData {
//   id: number;
//   judul: string;
//   isi: string;
//   created_at: string;
//   user: {
//     name: string;
//   };
//   comments: Comment[];
// }

// export default function Show({ auth, forum }: PageProps<{ forum: ForumData }>) {
//   const { data, setData, post, processing, reset } = useForm({
//     isi: '',
//   });

//   const handleSubmit = (e: React.FormEvent) => {
//     e.preventDefault();
//     post(route('comments.store', forum.id), {
//       onSuccess: () => reset(),
//     });
//   };

//   return (
//     <AppLayout>
//       <Head title={forum.judul} />
//       <div className="py-6">
//         <div className="max-w-4xl mx-auto sm:px-6 lg:px-8 space-y-6">
//           <div className="bg-white dark:bg-gray-800 p-6 shadow rounded">
//             <p className="text-gray-600 dark:text-gray-400 mb-2">
//                {forum.user.name} - {new Date(forum.created_at).toLocaleString()}
//             </p>
//             <p className="text-gray-900 dark:text-white">{forum.isi}</p>
//           </div>

         {/* ================================== */}

          {/* <div className="space-y-3">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-white">Komentar:</h3>
            {forum.comments.length === 0 ? (
              <p className="text-gray-500 dark:text-gray-400">Belum ada komentar.</p>
            ) : (
              forum.comments.map((comment) => (
                <div key={comment.id} className="border border-gray-200 dark:border-gray-700 p-3 rounded">
                  <p className="text-sm text-orange-700 dark:text-gray-400 mb-1">
                    {comment.user.name} - {new Date(comment.created_at).toLocaleString()}
                  </p>
                  <p className="text-gray-800 dark:text-white">{comment.isi}</p>
                </div>
              ))
            )}
          </div> */}

          {/* =============================================== */}

{/* <div className="space-y-3">
  <h3 className="text-lg font-semibold text-gray-800 dark:text-white">Komentar:</h3>

  {forum.comments.length === 0 ? (
    <p className="text-gray-500 dark:text-gray-400">Belum ada komentar.</p>
  ) : (
    forum.comments.map((comment) => (
      <div
        key={comment.id}
        className="border border-gray-200 dark:border-gray-700 p-3 rounded flex gap-3 items-start"
      >
        {/* Avatar inisial */}
        // <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-sm">
        //   {comment.user.name
        //     .split(' ')
        //     .map((n) => n[0])
        //     .join('')
        //     .slice(0, 2)
        //     .toUpperCase()}
        // </div> 

        {/* Konten komentar */}
  //       <div>
  //         <p className="text-sm font-bold text-orange-700 dark:text-gray-400 mb-1">
  //           {comment.user.name} - {new Date(comment.created_at).toLocaleString()}
  //         </p>
  //         <p className="text-gray-800 dark:text-white">{comment.isi}</p>
  //       </div>
  //     </div>
  //   ))
  // )}
// </div> 

  //         <form onSubmit={handleSubmit} className="bg-gray-50 dark:bg-gray-900 p-4 rounded shadow space-y-3">
  //           <textarea
  //             className="w-full border rounded p-2 dark:bg-gray-800 dark:text-white"
  //             placeholder="Tulis komentar..."
  //             value={data.isi}
  //             onChange={(e) => setData('isi', e.target.value)}
  //             required
  //           />
  //           <button
  //             type="submit"
  //             disabled={processing}
  //             className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
  //           >
  //             Kirim Komentar
  //           </button>
  //         </form>
  //       </div>
  //     </div>
  //   </AppLayout>
  // );
// }

import React from 'react';
import { Head, router, useForm } from '@inertiajs/react';
import AppLayout from '@/layouts/app-layout';
import { PageProps } from '@/types';
import { route } from 'ziggy-js';

interface Comment {
  id: number;
  isi: string;
  created_at: string;
  user: {
    id: number;
    name: string;
  };
}

interface ForumData {
  id: number;
  judul: string;
  isi: string;
  created_at: string;
  user: {
    name: string;
  };
  comments: Comment[];
}

export default function Show({ auth, forum }: PageProps<{ forum: ForumData }>) {
  const { data, setData, post, processing, reset } = useForm<{ isi: string }>({ isi: '' });
  const [editingCommentId, setEditingCommentId] = React.useState<number | null>(null);
  const [editContent, setEditContent] = React.useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    post(route('comments.store', forum.id), {
      preserveScroll: true,
      onSuccess: () => reset(),
    });
  };

  const startEditing = (comment: Comment) => {
    setEditingCommentId(comment.id);
    setEditContent(comment.isi);
  };

  const cancelEditing = () => {
    setEditingCommentId(null);
    setEditContent('');
  };

  const updateComment = () => {
    if (!editingCommentId) return;

    router.put(
      route('comments.update', editingCommentId),
      { isi: editContent },
      {
        preserveScroll: true,
        onSuccess: cancelEditing,
      }
    );
  };

  const deleteComment = (id: number) => {
    if (confirm('Yakin ingin menghapus komentar ini?')) {
      router.delete(route('comments.destroy', id), {
        preserveScroll: true,
      });
    }
  };

  return (
    <AppLayout>
      <Head title={forum.judul} />

      <div className="py-6">
        <div className="max-w-4xl mx-auto sm:px-6 lg:px-8 space-y-6">
          {/* Forum Section */}
          <div className="bg-white dark:bg-gray-800 p-6 shadow rounded">
            <p className="text-gray-600 dark:text-gray-400 mb-2">
              {forum.user.name} - {new Date(forum.created_at).toLocaleString()}
            </p>
            {/* <p className="text-gray-900 dark:text-white"></p> */}
            <div className="text-gray-800 dark:text-white whitespace-pre-line">{forum.isi}
</div>

          </div>

          {/* Komentar Section */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-white">Komentar:</h3>

            {forum.comments.length === 0 ? (
              <p className="text-gray-500 dark:text-gray-400">Belum ada komentar.</p>
            ) : (
              forum.comments.map((comment) => {
                const isOwner = auth.user.id === comment.user.id;

                return (
                  <div
                    key={comment.id}
                    className="border border-gray-200 dark:border-gray-700 p-3 rounded flex gap-3 items-start"
                  >
                    {/* Avatar */}
                    <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-sm">
                      {comment.user.name
                        .split(' ')
                        .map((n) => n[0])
                        .join('')
                        .slice(0, 2)
                        .toUpperCase()}
                    </div>

                    {/* Komentar */}
                    <div className="flex-1">
                      <p className="text-sm font-bold text-orange-700 dark:text-gray-400 mb-1">
                        {comment.user.name} - {new Date(comment.created_at).toLocaleString()}
                      </p>

                      {editingCommentId === comment.id ? (
                        <div className="space-y-2">
                          <textarea
                            value={editContent}
                            onChange={(e) => setEditContent(e.target.value)}
                            className="w-full p-2 rounded border dark:bg-gray-800 dark:text-white"
                          />
                          <div className="flex gap-2">
                            <button
                              onClick={updateComment}
                              className="px-3 py-1 bg-blue-600 text-white rounded"
                            >
                              Simpan
                            </button>
                            <button
                              onClick={cancelEditing}
                              className="px-3 py-1 bg-gray-400 text-white rounded"
                            >
                              Batal
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="text-gray-800 dark:text-white whitespace-pre-line">
  {comment.isi}
</div>

                      )}

                      {isOwner && editingCommentId !== comment.id && (
                        <div className="mt-2 flex gap-2 text-sm">
                          <button
                            onClick={() => startEditing(comment)}
                            className="text-blue-600 hover:underline"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => deleteComment(comment.id)}
                            className="text-red-600 hover:underline"
                          >
                            Hapus
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Form Komentar Baru */}
          <form
            onSubmit={handleSubmit}
            className="bg-gray-50 dark:bg-gray-900 p-4 rounded shadow space-y-3"
          >
            <textarea
              className="w-full border rounded p-2 dark:bg-gray-800 dark:text-white"
              placeholder="Tulis komentar..."
              value={data.isi}
              onChange={(e) => setData('isi', e.target.value)}
              required
            />
            <button
              type="submit"
              disabled={processing}
              className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
            >
              Kirim Komentar
            </button>
          </form>
        </div>
      </div>
    </AppLayout>
  );
}
