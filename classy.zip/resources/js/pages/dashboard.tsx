import { X, Users, CheckCircle, XCircle } from "lucide-react";
import AppLayout from '@/layouts/app-layout';
import { type BreadcrumbItem } from '@/types';
import { Head, usePage } from '@inertiajs/react';
import { Download } from "lucide-react";
import { useState } from "react";

const handleDownloadPDF = () => {
    window.open(route('export.pdf'), '_blank');
};

const handleDownloadExcel = () => {
    window.open(route('export.mahasiswa'), '_blank');
  };


const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Dashboard',
        href: '/dashboard',
    },
];

interface Mahasiswa {
    id: number;
    name: string;
    nim: string;
    kelas_id: number;
    kelas: {
        id: number;
        nama_kelas: string;
    };
    is_online: boolean;
}

interface Semester {
    id: number;
    name: string;
    nim: string;
    kelas_id: number;
    kelas: {
        id: number;
        nama_kelas: string;
    };
    is_online: boolean;
}

interface Tugas {
    id: number;
    nama_tugas: string;
    deskripsi: string;
    deadline: string;
    kelas_id: number;
    kelas: {
        id: number;
        nama_kelas: string;
    };
    categori_id: number;
    categori: {
        id: number;
        nama_categori: string;
    };
    jadwal_id: number;
}

export default function Dashboard() {
    const props = usePage().props;
    console.log("usePage().props:", props); 
    const mahasiswa = props.mahasiswa as Mahasiswa[] ?? [];
    const tugas = props.tugas as Tugas[] ?? [];
    const semester = props.semester as Semester[] ?? [];
    
    // State untuk mengatur sidebar
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);

    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="Dashboard" />
          
            <div className="flex h-full flex-1 flex-col gap-4 rounded-xl p-3">
        
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="rounded-lg bg-orange-500 p-4 text-white shadow-md">
                        <h2 className="text-lg font-semibold">Mahasiswa</h2>
                        <p className="mt-2 text-3xl font-bold">{mahasiswa.length}</p>
                    </div>
                    <div className="rounded-lg bg-orange-400 p-4 text-white shadow-md">
                        <h2 className="text-lg font-semibold">Tugas</h2>
                        <p className="mt-2 text-3xl font-bold">{tugas.length}</p>
                    </div>
                    <div className="rounded-lg bg-orange-300 p-4 text-white shadow-md">
                        <h2 className="text-lg font-semibold">Forum</h2>
                        <p className="mt-2 text-3xl font-bold">{semester.length}</p>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-10 gap-2">
                    {/* Tabel Mahasiswa */}
                    <div className="col-span-7 rounded-lg bg-gray-900 p-4 shadow-md">
                        <div className="overflow-x-auto shadow-md rounded-lg mt-1">
                            <table className="min-w-full text-sm border border-blue-300 rounded-lg overflow-hidden">
                                <thead className="bg-gradient-to-r from-blue-200 to-blue-300 text-gray-700">
                                    <tr>
                                        <th className="px-4 py-2 text-left border-b border-blue-300">Nama</th>
                                        <th className="px-4 py-2 text-left border-b border-blue-300">NIM</th>
                                        {/* <th className="px-4 py-2 text-left border-b border-blue-300">Status</th> */}
                                    </tr>
                                </thead>
                                <tbody className="text-gray-500">
                                    {Array.isArray(mahasiswa) && mahasiswa.length > 0 ? (
                                        mahasiswa.map((mhs) => (
                                            <tr
                                            key={mhs.id}
                                            className="transition duration-200 hover:bg-gray-300 even:bg-gray-200 odd:bg-gray-100">
                                          
                                                <td className="px-2 py-2 border-b border-blue-200">{mhs.name}</td>
                                                <td className="px-2 py-2 border-b border-blue-200">{mhs.nim}</td>
                                                {/* <td className="px-4 py-2 border-b border-blue-200">
                                                    <div className="flex items-center gap-2">
                                                        {mhs.is_online ? (
                                                            <CheckCircle className="text-green-400 w-5 h-5" />
                                                        ) : (
                                                            <XCircle className="text-blue-400 w-5 h-5" />
                                                        )}
                                                        <span>{mhs.is_online ? "Online" : "Offline"}</span>
                                                    </div>
                                                </td> */}
                                            </tr>
                                        ))
                                    ) : (
                                        <tr>
                                            <td colSpan={3} className="text-center text-orange-500 py-4">
                                                Tidak ada data mahasiswa.
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>

                    {/* Sidebar Mahasiswa Online */}
                    <div className={`col-span-3 ${isSidebarOpen ? "block" : "hidden"} bg-gray-900 shadow-md rounded-lg p-4`}>
                    <div className="flex justify-between items-center mb-2">
                        <div className="inline-flex items-center px-4 py-2 rounded-full border border-blue-500 bg-gradient-to-r from-blue-100 to-purple-100 text-blue-700 font-semibold shadow-sm">
                        Mahasiswa Online
                        <button 
                            onClick={() => setIsSidebarOpen(false)} 
                            className="ml-2 text-orange-500 hover:text-gray-700">
                            <X className="w-4 h-4" />
                        </button>
                        </div>
                    </div>

                    <div className="space-y-4 mt-4">
                        {mahasiswa.filter((mhs) => mhs.is_online).map((mhs) => (
                        <div key={mhs.id} className="flex items-center gap-2">
                            <Users className="text-green-400 w-6 h-6" />
                            <span className="font-bold text-orange-500">{mhs.name}</span>
                        </div>
                        ))}
                    </div>
                    </div>


                    {/* Tombol untuk membuka kembali sidebar */}
                    <div className="col-span-1">
                        {!isSidebarOpen && (
                           <button
                           onClick={() => setIsSidebarOpen(true)}
                           className="flex items-center justify-center gap-2 w-40 bg-orange-500 text-white py-3 px-5 rounded-lg shadow-lg hover:bg-orange-400"
                         >
                           <CheckCircle className="text-green-400 w-5 h-5" />
                           User Online
                         </button>
                         

                        )}
                    </div>
                </div>
{/* <div className="flex justify-end">
  <button
    onClick={handleDownloadPDF}
    className="inline-flex items-center gap-2 bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-lg shadow"
  >
    <Download className="w-5 h-5" />
    Download PDF
  </button>
</div>
 <button
          onClick={handleDownloadExcel}
          className="inline-flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white font-semibold py-3 px-3 rounded-lg shadow-md transition-colors duration-200"
          type="button"
        >
          Download Excel
        </button> */}
                <div className="grid auto-rows-min gap-3 md:grid-cols-3">
                    {[{ href: "https://event.unpam.ac.id/", img: "img/ems.png", alt: "EMS" },
                      { href: "https://my.unpam.ac.id/", img: "img/logounpam.png", alt: "Unpam" },
                      { href: "https://mentari.unpam.ac.id/", img: "img/mentari.png", alt: "Mentari" }].map(({ href, img, alt }, index) => (
                        <div
                          key={index}
                          className="border border-sidebar-border/70 dark:border-sidebar-border relative aspect-video overflow-hidden rounded-2xl bg-white dark:bg-gray-900 
                                     transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:ring-2 ring-primary/50 hover:rotate-1"
                        >
                          <a href={href} className="w-full h-full flex justify-center items-center">
                            <img
                              src={img}
                              alt={alt}
                              className={`object-contain grayscale hover:grayscale-0 transition-all duration-300
                                ${alt === "EMS" ? "max-h-34 max-w-70" : ""}
                                ${alt === "Mentari" ? "max-h-34 max-w-70" : ""}
                                ${alt === "Unpam" ? "max-h-40 max-w-40" : ""}
                              `}
                            />
                          </a>
                        </div>
                    ))}
                </div>

            </div>
        </AppLayout>
    );
}
