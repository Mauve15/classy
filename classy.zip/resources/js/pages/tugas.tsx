// import { useState } from 'react';
// import { Head, usePage } from '@inertiajs/react';
// import AppLayout from '@/layouts/app-layout';

// interface Jadwal {
//     id: number;
//     nama_matkul: string;
// }

// interface Tugas {
//     id: number;
//     nama_tugas: string;
//     deskripsi: string;
//     deadline: string;
//     jadwal?: Jadwal;
// }

// export default function Tugas() {
//     const { props } = usePage<{ tugas: Tugas[], kategori?: 'Individu' | 'Kelompok' }>();

//     const [kategori, setKategori] = useState<'Individu' | 'Kelompok'>(() => {
//         return props.kategori === 'Individu' || props.kategori === 'Kelompok' 
//             ? props.kategori 
//             : 'Individu';
//     });

//     const formatDate = (dateString: string) => {
//         const date = new Date(dateString);

//         // Format tanggal
//         const formattedDate = date.toLocaleDateString("id-ID", {
//             weekday: "long",   // Nama hari (Minggu, Senin, ...)
//             day: "2-digit",    // Tanggal (15)
//             month: "short",    // Singkatan bulan (Agu, Sep, ...)
//             year: "numeric"    // Tahun (25)
//         });

//         // Format waktu
//         const formattedTime = date.toLocaleTimeString("id-ID", {
//             hour: "2-digit",
//             minute: "2-digit",
//             second: "2-digit",
//             hour12: false      // Gunakan format 24 jam
//         });

//         return `${formattedDate} - ${formattedTime} WIB`;
//     };

//     const [tugas, setTugas] = useState<Tugas[]>(props.tugas);

//     const changeKategori = (newKategori: 'Individu' | 'Kelompok') => {
//         setKategori(newKategori);
//         window.location.href = `/tugas?kategori=${newKategori}`;
//     };

//     return (
//         <AppLayout>
//             <Head title="Tugas" />
//             <div className="p-4">
//                 <h1 className="text-sm font-bold mb-4">Daftar Tugas</h1>
//                 <div className="mb-4">
//                     <button 
//                         className={`px-4 py-2 ${kategori === 'Individu' ? 'bg-blue-500 text-white' : 'bg-gray-300'}`} 
//                         onClick={() => changeKategori('Individu')}>
//                         Individu
//                     </button>
//                     <button 
//                         className={`px-4 py-2 ${kategori === 'Kelompok' ? 'bg-blue-500 text-white' : 'bg-gray-300'}`} 
//                         onClick={() => changeKategori('Kelompok')}>
//                         Kelompok
//                     </button>
//                 </div>
//                 {/* =================================================================== */}
//                 {/* <table className="table-fixed w-full border">
//                     <thead>
//                         <tr className="bg-gray-200 text-sm">
//                             <th className="border px-2 py-2">Jadwal</th>
//                             <th className="border px-4 py-2">Nama Tugas</th>
//                             <th className="border px-2 py-2">Deskripsi</th>
//                             <th className="border px-2 py-2">Deadline</th>
//                         </tr>
//                     </thead>
//                     <tbody className='text-sm'>
//                         {tugas.length > 0 ? (
//                             tugas.map((item) => (
//                                 <tr key={item.id} className='text-sm'>
//                                     <td className="border px-1 py-1">
//                                         {item.jadwal ? item.jadwal.nama_matkul : '-'}
//                                     </td>
//                                     <td className="border px-2 py-2">{item.nama_tugas}</td>
//                                     <td className="border px-2 py-2">{item.deskripsi}</td>
//                                     <td className="border px-2 py-2">
//                                         {formatDate(item.deadline)}
//                                     </td>
//                                 </tr>
//                             ))
//                         ) : (
//                             <tr>
//                                 <td colSpan={4} className="text-center text-gray-500 py-2">
//                                     Tidak ada tugas tersedia
//                                 </td>
//                             </tr>
//                         )}
//                     </tbody>
//                 </table> */}
//                 {/* ==================================================================================== */}
//                 <div className="overflow-x-auto shadow-md rounded-lg">
//     <table className="min-w-full text-sm border border-gray-300 rounded-lg overflow-hidden">
//         <thead className="bg-gradient-to-r from-blue-100 to-blue-200 text-gray-700">
//             <tr>
//                 <th className="px-4 py-2 text-left border-b border-gray-300">Jadwal</th>
//                 <th className="px-4 py-2 text-left border-b border-gray-300">Nama Tugas</th>
//                 <th className="px-4 py-2 text-left border-b border-gray-300">Deskripsi</th>
//                 <th className="px-4 py-2 text-left border-b border-gray-300">Deadline</th>
//             </tr>
//         </thead>
//         <tbody className="text-gray-700">
//             {tugas.length > 0 ? (
//                 tugas.map((item) => (
//                     <tr
//                         key={item.id}
//                         className="hover:bg-blue-50 transition duration-200 ease-in-out even:bg-gray-50"
//                     >
//                         <td className="px-4 py-2 border-b border-gray-200">
//                             {item.jadwal ? item.jadwal.nama_matkul : '-'}
//                         </td>
//                         <td className="px-4 py-2 border-b border-gray-200">{item.nama_tugas}</td>
//                         <td className="px-4 py-2 border-b border-gray-200">{item.deskripsi}</td>
//                         <td className="px-4 py-2 border-b border-gray-200">
//                             {formatDate(item.deadline)}
//                         </td>
//                     </tr>
//                 ))
//             ) : (
//                 <tr>
//                     <td colSpan={4} className="text-center text-gray-500 py-4">
//                         Tidak ada tugas tersedia
//                     </td>
//                 </tr>
//             )}
//         </tbody>
//     </table>
// </div>

//             </div>
//         </AppLayout>
//     );
// }
import { useState } from 'react';
import { Head, usePage } from '@inertiajs/react';
import AppLayout from '@/layouts/app-layout';

interface Jadwal {
    id: number;
    nama_matkul: string;
}

interface Mahasiswa {
    id: number;
    name: string;
}

interface KelompokTugas {
    id: number;
    nama_kelompok: string;
    mahasiswa: Mahasiswa[];
}

interface Tugas {
    id: number;
    nama_tugas: string;
    deskripsi: string;
    deadline: string;
    jadwal?: Jadwal;
    kelompok_tugas?: KelompokTugas[];
}

export default function Tugas() {
    const { props } = usePage<{ tugas: Tugas[], kategori?: 'Individu' | 'Kelompok' }>();

    const [kategori, setKategori] = useState<'Individu' | 'Kelompok'>(() => {
        return props.kategori === 'Individu' || props.kategori === 'Kelompok' 
            ? props.kategori 
            : 'Individu';
    });

    const formatDate = (dateString: string) => {
        const date = new Date(dateString);

        const formattedDate = date.toLocaleDateString("id-ID", {
            weekday: "long",
            day: "2-digit",
            month: "short",
            year: "numeric"
        });

        const formattedTime = date.toLocaleTimeString("id-ID", {
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit",
            hour12: false
        });

        return `${formattedDate} - ${formattedTime} WIB`;
    };

    const [tugas, setTugas] = useState<Tugas[]>(props.tugas);

    const changeKategori = (newKategori: 'Individu' | 'Kelompok') => {
        if (newKategori !== kategori) {
            setKategori(newKategori);
            setTugas([]);
            window.location.href = `/tugas?kategori=${newKategori}`;
        }
    };

    return (
        <AppLayout>
            <Head title="Tugas" />
            <div className="p-4">
                <h1 className="text-sm font-bold mb-4">Daftar Tugas</h1>

                <p className="text-sm mb-2 text-gray-600">
                    Kategori saat ini: <strong>{kategori}</strong>
                </p>

                <div className="mb-4 space-x-2">
                    <button 
                        className={`px-4 py-2 rounded ${kategori === 'Individu' ? 'bg-blue-500 text-white' : 'bg-gray-300'}`} 
                        onClick={() => changeKategori('Individu')}>
                        Individu
                    </button>
                    <button 
                        className={`px-4 py-2 rounded ${kategori === 'Kelompok' ? 'bg-blue-500 text-white' : 'bg-gray-300'}`} 
                        onClick={() => changeKategori('Kelompok')}>
                        Kelompok
                    </button>
                </div>

                {kategori === 'Individu' ? (
                    <div className="overflow-x-auto shadow-md rounded-lg">
                        <table className="min-w-full text-sm border border-gray-300 rounded-lg overflow-hidden">
                            <thead className="bg-gradient-to-r from-blue-100 to-blue-200 text-gray-700">
                                <tr>
                                    <th className="px-4 py-2 text-left border-b border-gray-300">Jadwal</th>
                                    <th className="px-4 py-2 text-left border-b border-gray-300">Nama Tugas</th>
                                    <th className="px-4 py-2 text-left border-b border-gray-300">Deskripsi</th>
                                    <th className="px-4 py-2 text-left border-b border-gray-300">Deadline</th>
                                </tr>
                            </thead>
                            <tbody className="text-gray-700">
                                {tugas.length > 0 ? (
                                    tugas.map((item) => (
                                        <tr
                                            key={item.id}
                                            className="hover:bg-blue-50 transition duration-200 ease-in-out even:bg-gray-50"
                                        >
                                            <td className="px-4 py-2 border-b border-gray-200">
                                                {item.jadwal ? item.jadwal.nama_matkul : '-'}
                                            </td>
                                            <td className="px-4 py-2 border-b border-gray-200">{item.nama_tugas}</td>
                                            <td className="px-4 py-2 border-b border-gray-200">{item.deskripsi}</td>
                                            <td className="px-4 py-2 border-b border-gray-200">
                                                {formatDate(item.deadline)}
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan={4} className="text-center text-gray-500 py-4">
                                            Tidak ada tugas tersedia
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                ) : (
                    <div className="grid gap-4 md:grid-cols-2">
                        {tugas.length > 0 ? (
                            tugas.map((item) => (
                                <div key={item.id} className="bg-white rounded-xl border border-gray-300 shadow-md p-4">
                                    <h2 className="text-lg font-semibold text-blue-700 mb-2">
                                        {item.nama_tugas}
                                    </h2>
                                    <p className="text-sm text-gray-600 mb-1">
                                        <strong>Jadwal:</strong> {item.jadwal ? item.jadwal.nama_matkul : '-'}
                                    </p>
                                    <p className="text-sm text-gray-600 mb-1">
                                        <strong>Deskripsi:</strong> {item.deskripsi}
                                    </p>
                                    <p className="text-sm text-gray-600 mb-3">
                                        <strong>Deadline:</strong> {formatDate(item.deadline)}
                                    </p>

                                    <div className="space-y-3">
                                        {item.kelompok_tugas && item.kelompok_tugas.length > 0 ? (
                                            item.kelompok_tugas.map((kelompok) => (
                                                <div
                                                    key={kelompok.id}
                                                    className="border border-blue-100 bg-blue-50 rounded-lg p-3"
                                                >
                                                    <p className="text-sm font-semibold text-blue-600 mb-1">
                                                        {kelompok.nama_kelompok || 'Tanpa Nama'}
                                                    </p>
                                                    <ul className="list-disc ml-5 text-sm text-gray-700">
                                                        {kelompok.mahasiswa && kelompok.mahasiswa.length > 0 ? (
                                                            kelompok.mahasiswa.map((mahasiswa) => (
                                                                <li key={`mhs-${kelompok.id}-${mahasiswa.id}`}>
                                                                    {mahasiswa.name}
                                                                </li>
                                                            ))
                                                        ) : (
                                                            <li className="italic text-gray-400">
                                                                Belum ada anggota
                                                            </li>
                                                        )}
                                                    </ul>
                                                </div>
                                            ))
                                        ) : (
                                            <p className="text-gray-400 italic">Tidak ada kelompok</p>
                                        )}
                                    </div>
                                </div>
                            ))
                        ) : (
                            <p className="text-gray-500 italic">Tidak ada tugas kelompok tersedia</p>
                        )}
                    </div>
                )}
            </div>
        </AppLayout>
    );
}
