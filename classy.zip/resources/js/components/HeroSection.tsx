import { motion } from "framer-motion";
import { Link } from "@inertiajs/react";

export default function HeroSection() {
  return (
    <section className="min-h-screen flex flex-col lg:flex-row items-center justify-center gap-10 px-6 lg:px-20 bg-gradient-to-br from-amber-100 to-white dark:from-zinc-900 dark:to-zinc-800 transition-colors">
  {/* TEXT SECTION */}
  <motion.div
    className="w-full lg:w-1/2 text-center lg:text-left"
    initial={{ opacity: 0, y: 40 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.7 }}
  >
    <h1 className="text-4xl md:text-5xl font-extrabold mb-4">
      <span className="bg-gradient-to-r from-purple-800 via-red-500 to-orange-500 bg-clip-text text-transparent">
        Kelola Tugas dengan Mudah
      </span>
    </h1>
    <p className="text-zinc-700 dark:text-zinc-300 mb-6 text-lg">
      ClassyTask membantu kamu tetap produktif, ingat jadwal, dan menyelesaikan tugas tepat waktu.
    </p>
    <Link
      href="/dashboard"
      className="inline-block px-6 py-3 rounded-lg bg-amber-400 hover:bg-amber-500 text-black font-semibold text-sm shadow transition"
    >
      Mulai Sekarang
    </Link>
  </motion.div>

  {/* ILLUSTRATION */}
  <motion.div
    className="w-full lg:w-1/2 flex justify-center"
    initial={{ opacity: 0, scale: 0.8 }}
    animate={{ opacity: 1, scale: 1 }}
    transition={{ duration: 0.6, delay: 0.3 }}
  >
    <img
      src="img/classy.png"
      alt="Task Illustration"
      className="w-full max-w-sm md:max-w-md lg:max-w-lg rounded-xl"
    />
  </motion.div>
</section>

  );
}
