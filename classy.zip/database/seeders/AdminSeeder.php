<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            // 'nim' => '2310114450670',
            // 'kontak' => '081298502177',
            // 'prodi' => 'Teknik Informatika',
            // 'reguler' => true,
            // 'kelas_id' => 3,
            'role' => 'admin',
            'password' => Hash::make('admin123'),
        ]);
    }
}
